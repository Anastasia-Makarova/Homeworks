
Clean Folder
File sorter for a folder. Moves user files ii the given folder to separate folders due to the type of file.

version 0.1.1

Project is OS independent.

__________________________

ENTRY POINT name: clean-folder (path to the folder for sorting needed to be given after the space)
__________________________



Known file extentions:
"Audio":    ".mp3", ".wav", ".flac", ".wma", ".ogg", ".amr"
"Docs":     ".txt", ".doc", ".docx", ".xls", ".xlsx", ".pdf", ".ppt", ".pptx"
"Images":   ".jpg", ".jpeg",".png", ".svg", ".raf"
"Video":    ".mp4", ".mpeg", ".avi", ".mov", ".mkv"
"Archives": ".zip", ".gz", ".tar"

 